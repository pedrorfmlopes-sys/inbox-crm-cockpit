declare const Office: any;
